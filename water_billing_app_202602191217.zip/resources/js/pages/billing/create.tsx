import { Head, useForm, usePage, Link } from '@inertiajs/react';
import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem, type SharedData } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface Account {
    id: number;
    name: string;
    account_number: string;
}

interface CreateBillingPageProps {
    accounts: Account[];
    can: {
        create: boolean;
        generate: boolean;
    };
}

const breadcrumbs: BreadcrumbItem[] = [
    { title: 'Bills', href: route('billings.index') },
    { title: 'Generate Bill', href: '#' },
];

export default function CreateBilling() {
    const { accounts, can } = usePage<SharedData & CreateBillingPageProps>().props;
    
    const { data, setData, post, processing, errors } = useForm({
        account_id: '',
        billing_period: new Date().toISOString().slice(0, 7), // YYYY-MM format
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        post(route('billings.store'));
    };

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Generate Bill" />
            
            <div className="max-w-2xl mx-auto py-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Generate New Bill</CardTitle>
                        <CardDescription>
                            Generate a bill for an account based on their meter readings for the selected period.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        {!can.generate && (
                            <Alert className="mb-4">
                                <AlertCircle className="h-4 w-4" />
                                <AlertDescription>
                                    You do not have permission to generate bills.
                                </AlertDescription>
                            </Alert>
                        )}

                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div>
                                <Label htmlFor="account_id">Account *</Label>
                                <Select
                                    value={data.account_id}
                                    onValueChange={(value) => setData('account_id', value)}
                                    disabled={!can.generate || processing}
                                >
                                    <SelectTrigger className="mt-1">
                                        <SelectValue placeholder="Select account" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {accounts.map((account) => (
                                            <SelectItem key={account.id} value={account.id.toString()}>
                                                {account.name} ({account.account_number})
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                {errors.account_id && (
                                    <p className="text-sm text-red-600 mt-1">{errors.account_id}</p>
                                )}
                                <p className="text-sm text-gray-500 mt-1">
                                    Select the account to generate a bill for
                                </p>
                            </div>

                            <div>
                                <Label htmlFor="billing_period">Billing Period *</Label>
                                <Input
                                    id="billing_period"
                                    type="month"
                                    value={data.billing_period}
                                    onChange={(e) => setData('billing_period', e.target.value)}
                                    disabled={!can.generate || processing}
                                    className="mt-1"
                                />
                                {errors.billing_period && (
                                    <p className="text-sm text-red-600 mt-1">{errors.billing_period}</p>
                                )}
                                <p className="text-sm text-gray-500 mt-1">
                                    The month and year for which to generate the bill
                                </p>
                            </div>

                            <Alert>
                                <AlertCircle className="h-4 w-4" />
                                <AlertDescription>
                                    The system will automatically calculate consumption based on meter readings 
                                    and apply the appropriate tariff rates.
                                </AlertDescription>
                            </Alert>

                            <div className="flex gap-2 justify-end">
                                <Link href={route('billings.index')}>
                                    <Button type="button" variant="outline">
                                        Cancel
                                    </Button>
                                </Link>
                                <Button 
                                    type="submit" 
                                    disabled={!can.generate || processing}
                                >
                                    {processing ? 'Generating...' : 'Generate Bill'}
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </AppLayout>
    );
}