import { Inertia } from "@inertiajs/inertia";
import { PageProps } from "@/types/inertia";

export default function ForMeter(props: PageProps) {
    return (
        <div>
            <h1>For Meter</h1>
        </div>
    );
}