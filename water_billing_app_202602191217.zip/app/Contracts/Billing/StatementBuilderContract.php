<?php

namespace App\Contracts\Billing;

interface StatementBuilderContract
{
    //
}