<?php

namespace App\Contracts\Billing;

interface BillingServiceContract
{
    //
}