<?php

namespace App\Actions\Billing;

class SendStatement
{
    //
}