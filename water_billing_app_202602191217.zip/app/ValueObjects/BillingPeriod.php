<?php

namespace App\ValueObjects;

class BillingPeriod
{
    //
}