<?php

namespace App\Exceptions\Billing;

use RuntimeException;

abstract class BillingException extends RuntimeException
{
    //
}
