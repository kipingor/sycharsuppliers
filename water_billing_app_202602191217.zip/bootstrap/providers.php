<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\BillingServiceProvider::class,
    App\Providers\EventServiceProvider::class,
];
