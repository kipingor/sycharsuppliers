<?php


return [
    'unit_price' => env('WATER_BILLING_UNIT_PRICE', 300),
];