<?php

namespace Tests\Unit\Billing;

use PHPUnit\Framework\TestCase;

class ChargeCalculatorTest extends TestCase
{
    /**
     * A basic unit test example.
     */
    public function test_example(): void
    {
        $this->assertTrue(true);
    }
}
